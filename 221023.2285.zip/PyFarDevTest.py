from multiprocessing.dummy import shutdown
import colorama
from playsound import playsound
from colorama import Fore,Style,Back
colorama.init(autoreset=True)
print(Fore.CYAN+"© PyOSes Pre-release")
import time
import sys
time.sleep(2)
print(Fore.MAGENTA+"PyFar version:")
time.sleep(1)
print(Fore.LIGHTRED_EX+"Dev Preview Build 221023.2285")
time.sleep(6)
import random
import datetime
print("Loading...")
time.sleep(2)
print("[INFO] Rewriting previous versions...")
time.sleep(3)
print(Fore.RED+"[INFO] Finding errors...")
time.sleep(2)
print("[INFO] Loading debug information...")
time.sleep(5)
print("[INFO] Starting debug...")
time.sleep(0.5)
print("[INFO]Starting debug at line 55 sec 162 reloading the FileBank...")
time.sleep(0.3)
print("[INFO] Finding in ProgramFiles...")
time.sleep(0.2)
print("[INFO] Breaking up the Taskbar...")
time.sleep(0.1)
print("[INFO]Reloading...")
time.sleep(1)
print("[INFO] Debugging sec 10023...")
time.sleep(3)
print("[INFO] Reloading D drive...")
time.sleep(0.3)
print("[INFO] Finding in Kernel...")
time.sleep(0.2)
print("[INFO] Reloading system reserved drives...")
time.sleep(0.5)
print("[INFO] Finding in system protected files...")
time.sleep(0.2)
print("[INFO] Reloading...")
time.sleep(0.1)
print("[INFO] Finding in system32...")
time.sleep(0.2)
print("[INFO] Finding in comdlg32.dll...")
time.sleep(0.4)
print("[INFO] Finding in gld32.dll...")
time.sleep(0.2)
print("[INFO] Finding in kernel32.dll...")
time.sleep(0.1)
print("[INFO] Finding in user32.dll...")
time.sleep(0.1)
print("[INFO] Finding in aclayers.dll...")
time.sleep(0.1)
print("[INFO] Finding in bdesvc.dll...")
time.sleep(0.1)
print("[INFO] Finding in bi.dll...")
time.sleep(0.1)
print("[INFO] Finding in catsrvps.dll...")
time.sleep(0.1)
print("[INFO] Finding in datausage.dll...")
time.sleep(0.1)
print("[INFO] Finding in encapi.dll...")
time.sleep(0.1)
print("[INFO] Finding in fhevents.dll...")
time.sleep(0.1)
print("[INFO] Finding in SysWOW64...")
time.sleep(5)
print("[INFO] Finding in bootmgr.exe...")
time.sleep(0.1)
print("[INFO] Finding in bootmgr.dll...")
time.sleep(0.1)
print("[INFO] Finding in aeinv.dll...")
time.sleep(0.1)
print("[INFO] Finding in authfwcfg.dll...")
time.sleep(0.1)
print("[INFO] Finding in bcrypt.dll...")
time.sleep(0.1)
print("[INFO] Finding in bootvid.dll...")
time.sleep(0.1)
print("[INFO] Finding in bootmenuux.dll...")
time.sleep(0.1)
print("[INFO] Finding in boot.sdi...")
time.sleep(0.1)
print("[INFO] Finding in calc.exe...")
time.sleep(0.1)
print("[INFO] Finding in capisp.dll...")
time.sleep(0.1)
print("[INFO] Finding in clipsvc.dll...")
time.sleep(0.1)
print("[INFO] Finding in aadtb.dll...")
time.sleep(0.1)
print("[INFO] Reloading...")
time.sleep(3)
print("[INFO] Finding in comp.dll...")
time.sleep(0.1)
print("[INFO] Finding in Users...")
time.sleep(0.1)
print("[INFO] Finding in bootmgr.dll...")
time.sleep(0.1)
print("[INFO] Finding in cipher.exe...")
time.sleep(0.1)
print("[INFO] Finding in clip.exe...")
time.sleep(0.1)
print("[INFO] Finding in cliconfig.exe...")
time.sleep(0.1)
print("[INFO] Finding in cmd.exe...")
time.sleep(0.1)
print("[INFO] Finding in cmdext.dll...")
time.sleep(0.1)
print("[INFO] Finding in compact.exe...")
time.sleep(0.1)
print("[INFO] Finding in compmgmt.msc...")
time.sleep(0.1)
print("[INFO] Finding in comres.dll...")
time.sleep(0.1)
print("[INFO] Finding in Appdata...")
time.sleep(10)
print(Fore.BLUE+"[INFO] No errors are found!")
time.sleep(1)
print(Fore.LIGHTCYAN_EX+"[INFO] Loading library...")
time.sleep(3)
print(Fore.LIGHTYELLOW_EX+"[INFO] Preparing imports...")
time.sleep(2)
def delay_print(s):
    for c in s:
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0.1)
def delay_print_load(s):
    for c in s:
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0.5)
def delay_print_logo(s):
    for c in s:
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0.00001)
print(Fore.GREEN+"[INFO] Getting finished...")
time.sleep(3)
print(Fore.MAGENTA+"[INFO] Preparing to start running...")
time.sleep(5)
print(Fore.LIGHTRED_EX+"[INFO] Finished!")
time.sleep(2)
delay_print("Please wait...")
time.sleep(0.5)
for i in range(5):
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
delay_print("To proof that you got access from PyOSes to use this pre-release, enter the correct pre-release username.")
time.sleep(3)
print("                                 ")
username=str(input("Enter the username to use this Dev build: "))

while True:
    def verifyidentity(username):
        if username == "devtest":
            return "devtest"
        else:
            return "usernotfound"
    identity=verifyidentity
    if username == "devtest":
        print("Welcome Developer test! Preparing.....Please wait patiently!")
        time.sleep(5)
        print("_")
        time.sleep(0.5)
        print(" ")
        print(r"/")
        time.sleep(0.5)
        print("_")
        time.sleep(0.5)
        print(r"|")
        print("_")
        time.sleep(0.5)
        time.sleep(5)
        print("_")
        time.sleep(0.5)
        print(" ")
        print(r"/")
        time.sleep(0.5)
        print("_")
        time.sleep(0.5)
        print(r"|")
        print("_")
        time.sleep(0.5)
        time.sleep(2)
        rfer=random.randint(1,100)
        if rfer==21:
            print("[ERROR] No bootable medium or operating system found.")
            print("[INFO] Please restart shell or contact support at the 阿塊 Discord server.")
            time.sleep(10000)
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print(Fore.RED+"               Republic of Gamers           ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print(Back.CYAN+"Booting BIOS UEFI please wait.")
        time.sleep(0.5)
        print(Back.CYAN+"Booting BIOS UEFI please wait..")
        time.sleep(0.5)
        print(Back.CYAN+"Booting BIOS UEFI please wait...")
        time.sleep(0.5)
        print(Back.CYAN+"Booting BIOS UEFI please wait.")
        time.sleep(0.5)
        print(Back.CYAN+"Booting BIOS UEFI please wait..")
        time.sleep(0.5)
        print(Back.CYAN+"Booting BIOS UEFI please wait...")
        time.sleep(0.5)
        print(Back.CYAN+"Booting BIOS UEFI please wait.")
        time.sleep(0.5)
        print(Back.CYAN+"Booting BIOS UEFI please wait..")
        time.sleep(0.5)
        print(Back.CYAN+"Booting BIOS UEFI please wait...")
        time.sleep(0.5)
        print(Back.CYAN+"Booting BIOS UEFI please wait.")
        time.sleep(0.5)
        print(Back.CYAN+"Booting BIOS UEFI please wait..")
        time.sleep(0.5)
        print(Back.CYAN+"Booting BIOS UEFI please wait...")
        time.sleep(5)
        print(Fore.MAGENTA+"American Megatrends")
        time.sleep(3)
        delay_print_load("████████████████████")
        time.sleep(6)
        print("                     ")
        print("Boot options:")
        time.sleep(1.5)
        print("Boot option 1: Windows 11 Dev Build 22504.1010")
        time.sleep(1.5)
        print("Boot option two:")
        installusb = str(input(
            "SanDisk 64GB RCs283097 (USB Mass Storage Device).Is this the right boot disk/USB to boot installer?  Yes/No  "))
        time.sleep(1)
        if installusb == "No":
            corinusb= str(input("Please enter your boot installer:  "))
        else:
            pass
        print("Loading...")
        time.sleep(0.5)
        print("Loading...")
        time.sleep(0.5)
        print("Loading...")
        time.sleep(0.5)
        print("Loading...")
        time.sleep(5)
        print("Settings changed!")
        time.sleep(3)
        print("PyFar will have to restart to apply BIOS setting to the OS.")
        time.sleep(0.5)
        print("Restarting in 3...")
        time.sleep(0.5)
        print("Restarting in 2...")
        time.sleep(0.5)
        print("Restarting in 1...")
        time.sleep(1)
        print("Preparing to restart.....")
        time.sleep(3)
        print("Shutting down")
        time.sleep(1)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")

        time.sleep(5)
        print(Fore.RED+"               Republic of Gamers           ")
        time.sleep(3)
        delay_print_load("████████████████████")
        time.sleep(4)
        print("                     ")
        delay_print_logo("""
        
────────────────────────────────────────────────────────────────────────────────────
─██████████████─████████──████████─██████████████─██████████████─████████████████───
─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████░░██─████░░██──██░░████─██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░██──██░░██───██░░░░██░░░░██───██░░██─────────██░░██──██░░██─██░░██────██░░██───
─██░░██████░░██───████░░░░░░████───██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░░░░░░░░░██─────████░░████─────██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████████───────██░░██───────██░░██████████─██░░██████░░██─██░░██████░░████───
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██─────
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██████─
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░░░░░██─
─██████───────────────██████───────██████─────────██████──██████─██████──██████████─
────────────────────────────────────────────────────────────────────────────────────
────────────────────────────────────────────────────────────────────────────
─██████████████─██████████████─██████████████─██████──██████─██████████████─
─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██──██░░██─██░░░░░░░░░░██─
─██░░██████████─██░░██████████─██████░░██████─██░░██──██░░██─██░░██████░░██─
─██░░██─────────██░░██─────────────██░░██─────██░░██──██░░██─██░░██──██░░██─
─██░░██████████─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████░░██─
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░██──██░░██─██░░░░░░░░░░██─
─██████████░░██─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████████─
─────────██░░██─██░░██─────────────██░░██─────██░░██──██░░██─██░░██─────────
─██████████░░██─██░░██████████─────██░░██─────██░░██████░░██─██░░██─────────
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░░░░░░░░░██─██░░██─────────
─██████████████─██████████████─────██████─────██████████████─██████─────────
────────────────────────────────────────────────────────────────────────────
        
        
        
        """)
        time.sleep(5)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")

        print("This is PyFar™ official installation.")
        time.sleep(5)
        print("Please choose your installation disk")
        time.sleep(0.5)
        disk = str(input("Enter your disk installation path:"))
        time.sleep(0.7)
        iso = str(input("Please choose you PyFar installation ISO image:"))
        time.sleep(5)
        print(Fore.CYAN+"Copying installation files    0%")
        time.sleep(5)
        print(Fore.CYAN+"Copying installation files    100%")
        time.sleep(0.5)
        print(Fore.GREEN+"Getting files ready for installation   0%")
        time.sleep(3)
        print(Fore.GREEN+"Getting files ready for installation   100%")
        time.sleep(0.5)
        print(Fore.LIGHTBLUE_EX+"Installing features   0%")
        time.sleep(10)
        print(Fore.LIGHTBLUE_EX+"Installing features   100%")
        time.sleep(0.5)
        print(Fore.LIGHTMAGENTA_EX+"Installing updates   0%")
        time.sleep(15)
        print(Fore.LIGHTMAGENTA_EX+"Installing updates     100%")
        time.sleep(0.5)
        print(Fore.LIGHTRED_EX+"Getting finished         0%")
        time.sleep(5)
        print("PyFar™ have to restart to complete preparing for the installation.")
        time.sleep(2)
        print("Restarting in 3")
        time.sleep(2)
        print("Restarting in 2")
        time.sleep(2)
        print("Restarting in 1")
        time.sleep(0.7)
        print("Preparing to restart.....")
        time.sleep(3)
        print("Shutting down")
        time.sleep(1)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        time.sleep(5)
        print(Fore.RED+"               Republic of Gamers           ")
        time.sleep(3)
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        time.sleep(3)
        delay_print_load("████████████████████")
        print("                     ")
        time.sleep(5)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        time.sleep(0.7)
        print(Fore.LIGHTRED_EX+"Getting finished         100%")
        time.sleep(5)
        print("Loading administrator settings......")
        time.sleep(2)
        delay_print("Hello! Welcome to PyFar™!")
        time.sleep(1)
        delay_print_logo("©2022 PyOSes Corporation")
        time.sleep(4)
        print("                     ")
        delay_print_logo("""
        
────────────────────────────────────────────────────────────────────────────────────
─██████████████─████████──████████─██████████████─██████████████─████████████████───
─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████░░██─████░░██──██░░████─██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░██──██░░██───██░░░░██░░░░██───██░░██─────────██░░██──██░░██─██░░██────██░░██───
─██░░██████░░██───████░░░░░░████───██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░░░░░░░░░██─────████░░████─────██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████████───────██░░██───────██░░██████████─██░░██████░░██─██░░██████░░████───
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██─────
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██████─
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░░░░░██─
─██████───────────────██████───────██████─────────██████──██████─██████──██████████─
────────────────────────────────────────────────────────────────────────────────────
────────────────────────────────────────────────────────────────────────────
─██████████████─██████████████─██████████████─██████──██████─██████████████─
─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██──██░░██─██░░░░░░░░░░██─
─██░░██████████─██░░██████████─██████░░██████─██░░██──██░░██─██░░██████░░██─
─██░░██─────────██░░██─────────────██░░██─────██░░██──██░░██─██░░██──██░░██─
─██░░██████████─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████░░██─
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░██──██░░██─██░░░░░░░░░░██─
─██████████░░██─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████████─
─────────██░░██─██░░██─────────────██░░██─────██░░██──██░░██─██░░██─────────
─██████████░░██─██░░██████████─────██░░██─────██░░██████░░██─██░░██─────────
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░░░░░░░░░██─██░░██─────────
─██████████████─██████████████─────██████─────██████████████─██████─────────
────────────────────────────────────────────────────────────────────────────
        
        
        
        """)
        time.sleep(2)
        delay_print("But, before installing, activate PyFar with your product key!")
        print("                     ")
        prokey: str = str(input("Please enter your product key:"))
        if prokey != "prokey":
            print("Your product key is invalid. Please get a new one.")
            time.sleep(1000000)
        else:
            print("Thank you for choosing PyOSes! We are activating your PyFar™ installation.")
            time.sleep(2)
            print("Please wait.")
            time.sleep(0.5)
            print("Please wait..")
            time.sleep(0.5)
            print("Please wait...")
            time.sleep(0.5)
            print("Please wait.")
            time.sleep(0.5)
            print("Please wait..")
            time.sleep(0.5)
            print("Please wait...")
            time.sleep(0.5)
            print("Please wait.")
            time.sleep(0.5)
            print("Please wait..")
            time.sleep(0.5)
            print("Please wait...")
            time.sleep(5)
            print("Finished!")
            time.sleep(2)
        hwrr = str(input("Please enter a computer ID:"))
        delay_print(hwrr)
        time.sleep(1)
        print("We are applying the ID to your computer.")
        time.sleep(0.5)
        print("We are applying the ID to your computer..")
        time.sleep(0.5)
        print("We are applying the ID to your computer...")
        time.sleep(0.5)
        print("We are applying the ID to your computer.")
        time.sleep(0.5)
        print("We are applying the ID to your computer..")
        time.sleep(0.5)
        print("We are applying the ID to your computer...")
        time.sleep(0.5)
        print("We are applying the ID to your computer.")
        time.sleep(0.5)
        print("We are applying the ID to your computer..")
        time.sleep(0.5)
        print("We are applying the ID to your computer...")
        time.sleep(3)
        print("Your computer have to restart to complete applying.")
        dywtr = str(input("Enter 'Restart now' to restart."))
        if dywtr == "Restart now" or dywtr == "restart now":
            print("Preparing to restart.....")
            time.sleep(3)
            print("Shutting down")
            time.sleep(1)
            print("                                                              ")
            print("                                                              ")
            print("                                                              ")
            print("                                                              ")
            print("                                                              ")
            print("                                                              ")
        time.sleep(5)
        print(Fore.RED+"               Republic of Gamers           ")
        time.sleep(3)
        delay_print_load("████████████████████")
        time.sleep(4)
        print("                     ")
        delay_print_logo("""
        
────────────────────────────────────────────────────────────────────────────────────
─██████████████─████████──████████─██████████████─██████████████─████████████████───
─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████░░██─████░░██──██░░████─██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░██──██░░██───██░░░░██░░░░██───██░░██─────────██░░██──██░░██─██░░██────██░░██───
─██░░██████░░██───████░░░░░░████───██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░░░░░░░░░██─────████░░████─────██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████████───────██░░██───────██░░██████████─██░░██████░░██─██░░██████░░████───
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██─────
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██████─
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░░░░░██─
─██████───────────────██████───────██████─────────██████──██████─██████──██████████─
────────────────────────────────────────────────────────────────────────────────────
────────────────────────────────────────────────────────────────────────────
─██████████████─██████████████─██████████████─██████──██████─██████████████─
─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██──██░░██─██░░░░░░░░░░██─
─██░░██████████─██░░██████████─██████░░██████─██░░██──██░░██─██░░██████░░██─
─██░░██─────────██░░██─────────────██░░██─────██░░██──██░░██─██░░██──██░░██─
─██░░██████████─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████░░██─
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░██──██░░██─██░░░░░░░░░░██─
─██████████░░██─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████████─
─────────██░░██─██░░██─────────────██░░██─────██░░██──██░░██─██░░██─────────
─██████████░░██─██░░██████████─────██░░██─────██░░██████░░██─██░░██─────────
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░░░░░░░░░██─██░░██─────────
─██████████████─██████████████─────██████─────██████████████─██████─────────
────────────────────────────────────────────────────────────────────────────
        
        
        
        """)
        time.sleep(5)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("Checking for updates.....")
        print("This may take up to 2 minutes")
        xeuk = random.randint(5, 11)
        time.sleep(xeuk)
        innow = str(input("Enter 'Install now' to install all downloaded updates.]  "))
        time.sleep(1)
        print("Please wait...")
        time.sleep(3)
        for i in range(1, 20):
            print("                           ")
            print("                           ")
            print("                           ")
            print("                           ")

        time.sleep(2)
        print("License terms")
        time.sleep(1)
        print("                           ")
        print("                           ")
        print("                           ")
        print("                           ")
        delay_print("PyOSES PRE-RELEASE SOFTWARE LICENSE TERMS")
        print("                           ")
        delay_print("PRE-RELEASE PYFAR™ OPERATING SYSTEM")
        print("                           ")
        delay_print("IF YOU LIVE IN(OR IF A BUSINESS, YOUR PRINCIPAL PLACE")
        delay_print("OF BUSINESS IS IN) THE UNITED STATES, SECTION 1 OF")
        delay_print("THE ADDITIONAL TERMS CONTAINS A BINDING")
        delay_print("ARBITRATION CLAUSE AND CLASS ACTION WAVIER. IT")
        delay_print("AFFECTS YOUR RIGHTS TO RESOLVE A DISPUTE WITH")
        delay_print("PYOSES. PLEASE READ IT.")
        time.sleep(1)
        termacc = str(input("By installing, you agree to the terms and license.Do you agree? Yes/No  "))
        time.sleep(0.5)
        if termacc == "Yes":
            print("You accepted it!")
        else:
            print("You rejected it! Only people who agree in the terms and license can install.")
            print("PyFar Error: You can't install PyFar.")
            time.sleep(10)
            break
        print("Please wait...")
        time.sleep(2)
        cor = str(input("Is Taiwan the right country/region for you? Yes/No  "))
        time.sleep(0.5)
        if cor == "Yes":
            print(Fore.RED+"Got it!")
        else:
            corcor=str(input("Please enter you country/region: "))
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(3)
        print("Finished!")
        time.sleep(2)
        lang = str(input("Is US the right language for you? Yes/No  "))
        time.sleep(0.5)
        if  lang == "Yes":
            print(Fore.YELLOW+"Okay!")
        else:
            corlang=str(input("Please enter your language: "))
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(3)
        print("Finished!")
        time.sleep(2)
        kim = str(input("Is Chinese Traditional(Microsoft Array) the right keyboard layout for you? Yes/No  "))
        time.sleep(0.5)
        if kim == "Yes":
            print(Fore.GREEN+"Alright!")
        else:
            corkim= str(input("Please enter your keyboard layout for you: "))
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(3)
        print("Finished!")
        time.sleep(1)
        akim = str(input("Do you want to add another keyboard layout? Yes/No  "))
        if akim == "Yes":
            wiakim = str(input("Which other keyboard layout do you want?  "))
        else:
            print(Fore.BLUE+"We got it!")
            time.sleep(0.5)
            print("Applying.")
            time.sleep(0.5)
            print("Applying..")
            time.sleep(0.5)
            print("Applying...")
            time.sleep(0.5)
            print("Applying.")
            time.sleep(0.5)
            print("Applying..")
            time.sleep(0.5)
            print("Applying...")
            time.sleep(0.5)
            print("Applying.")
            time.sleep(0.5)
            print("Applying..")
            time.sleep(0.5)
            print("Applying...")
            time.sleep(3)
            print("Finished!")
        time.sleep(4)
        print("Please wait......")
        time.sleep(5)
        print("PyFar™ have to restart to apply the settings.")
        time.sleep(2)
        print("Restarting in 3")
        time.sleep(2)
        print("Restarting in 2")
        time.sleep(2)
        print("Restarting in 1")
        time.sleep(0.7)
        print("Preparing to restart.....")
        time.sleep(3)
        print("Shutting down")
        time.sleep(1)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        time.sleep(5)
        print(Fore.RED+"               Republic of Gamers           ")
        time.sleep(3)
        delay_print_load("████████████████████")
        print("                     ")
        time.sleep(2)
        delay_print_logo
        ("""
        
────────────────────────────────────────────────────────────────────────────────────
─██████████████─████████──████████─██████████████─██████████████─████████████████───
─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████░░██─████░░██──██░░████─██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░██──██░░██───██░░░░██░░░░██───██░░██─────────██░░██──██░░██─██░░██────██░░██───
─██░░██████░░██───████░░░░░░████───██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░░░░░░░░░██─────████░░████─────██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████████───────██░░██───────██░░██████████─██░░██████░░██─██░░██████░░████───
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██─────
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██████─
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░░░░░██─
─██████───────────────██████───────██████─────────██████──██████─██████──██████████─
────────────────────────────────────────────────────────────────────────────────────
────────────────────────────────────────────────────────────────────────────
─██████████████─██████████████─██████████████─██████──██████─██████████████─
─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██──██░░██─██░░░░░░░░░░██─
─██░░██████████─██░░██████████─██████░░██████─██░░██──██░░██─██░░██████░░██─
─██░░██─────────██░░██─────────────██░░██─────██░░██──██░░██─██░░██──██░░██─
─██░░██████████─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████░░██─
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░██──██░░██─██░░░░░░░░░░██─
─██████████░░██─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████████─
─────────██░░██─██░░██─────────────██░░██─────██░░██──██░░██─██░░██─────────
─██████████░░██─██░░██████████─────██░░██─────██░░██████░░██─██░░██─────────
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░░░░░░░░░██─██░░██─────────
─██████████████─██████████████─────██████─────██████████████─██████─────────
────────────────────────────────────────────────────────────────────────────
        
        
        
        """)
        time.sleep(5)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        time.sleep(3)
        for i in range(4):
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
        print("Let's finish setting up your device!")
        for i in range(2):
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
        time.sleep(3)
        print("First, enter your PyOS account!")
        time.sleep(1)
        print(Fore.BLUE+"Logging in is not necessary but it's better because you can backup your files and use more features!")
        time.sleep(1)
        print(Fore.MAGENTA+"Don't have one?")
        time.sleep(0.5)
        print(Fore.CYAN+"Create an account!")
        time.sleep(2)
        haact=str(input("Do you have an account? Yes/No  "))
        print(Fore.YELLOW+"Please wait......")
        time.sleep(2)
        if haact == "No":
            print(Fore.RED+"Detecting browser...")
            time.sleep(2)
            import webbrowser
            webbrowser.open_new_tab("https://tiny.one/pyoses-register")
            time.sleep(2)
            print("If your browser didn't start or open the link, please contact support at the 阿塊 Discord server.")
            time.sleep(3)
            print("A secret 6-digit log in code should have been given to you after registration.")
            lisc=str(input("Enter your secret log in code:"))
            if lisc=="BQ362E":
                print("Match!")
                time.sleep(2)
            else:
                print("Please register again")
        if haact == "Yes":
            print(Fore.GREEN+"You need to enter your email and password in order to log in.")
            email=str(input("Email:"))
            epps=str(input("Password:"))
            print("Password correct!")
            time.sleep(2)
        print(Fore.RED+"Log in complete!")
        print("PyFar™ have to restart to apply your account.")
        time.sleep(2)
        print("Restarting in 3")
        time.sleep(2)
        print("Restarting in 2")
        time.sleep(2)
        print("Restarting in 1")
        time.sleep(0.7)
        print("Preparing to restart.....")
        time.sleep(3)
        print("Shutting down")
        time.sleep(1)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        time.sleep(5)
        print(Fore.RED+"               Republic of Gamers           ")
        time.sleep(3)
        delay_print_load("████████████████████")
        time.sleep(5)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        time.sleep(5)
        print("Hi!")
        time.sleep(2)
        delay_print("The next step will be very important!")
        time.sleep(1)
        print(Fore.RED+"DO NOT TURN OFF OR UNPLUG YOUR COMPUTER! IT MAY DESTROY THE WHOLE INSTALLATION!")
        time.sleep(2)
        print(Fore.LIGHTCYAN_EX+"Please sit back while you are enjoying our magic!")
        time.sleep(4)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(5)
        print("Checking registry settings.....")
        time.sleep(2)
        print("Now, What's new?")
        time.sleep(2)
        print("Let's check out new things in this new OS!")
        time.sleep(5)
        print("More codes available")
        time.sleep(4)
        delay_print(
            "In PyFar™, more terminal codes and Python support etc. is available. This is a great choice for programmers to use.")
        time.sleep(4)
        delay_print("No more MS-DOS")
        time.sleep(4)
        delay_print(
            "In this edition, it in Python! But not like MS-DOS of Microsoft, it is just running on Python. Don't worry, it'll work as normal and even faster.")
        time.sleep(4)
        delay_print("'PyFar'")
        time.sleep(4)
        delay_print(
            "'PyFar', special name, huh? Yep! There's a meaning behind it!")
        time.sleep(2)
        delay_print("'PyFar' actually means: 'By far', the most powerful operating system.")
        time.sleep(4)
        delay_print("And more features that you can find out later!")
        time.sleep(5)
        delay_print_logo("Please wait...")
        time.sleep(2)
        delay_print("Loading operating system Python code....")
        time.sleep(8)
        print("Almost there.")
        time.sleep(3)
        delay_print_logo("Please wait while FarCore is starting up winhost.exe......")
        time.sleep(1)
        print("Fun fact: FarCore is like the Kernel in Windows and winhost.exe controls the processes and windows!")
        time.sleep(6)
        vcpwd = int(input("Enter password:"))
        if vcpwd == 20130714:
            print(Back.LIGHTYELLOW_EX+"Welcome")
            time.sleep(0.5)
            time.sleep(3)
            delay_print_load("████████████████████████████████████████")
            print("                     ")
            delay_print_logo("""
░██╗░░░░░░░██╗███████╗██╗░░░░░░█████╗░░█████╗░███╗░░░███╗███████╗
░██║░░██╗░░██║██╔════╝██║░░░░░██╔══██╗██╔══██╗████╗░████║██╔════╝
░╚██╗████╗██╔╝█████╗░░██║░░░░░██║░░╚═╝██║░░██║██╔████╔██║█████╗░░
░░████╔═████║░██╔══╝░░██║░░░░░██║░░██╗██║░░██║██║╚██╔╝██║██╔══╝░░
░░╚██╔╝░╚██╔╝░███████╗███████╗╚█████╔╝╚█████╔╝██║░╚═╝░██║███████╗
░░░╚═╝░░░╚═╝░░╚══════╝╚══════╝░╚════╝░░╚════╝░╚═╝░░░░░╚═╝╚══════╝

██████╗░░█████╗░░█████╗░██╗░░██╗  ████████╗░█████╗░
██╔══██╗██╔══██╗██╔══██╗██║░██╔╝  ╚══██╔══╝██╔══██╗
██████╦╝███████║██║░░╚═╝█████═╝░  ░░░██║░░░██║░░██║
██╔══██╗██╔══██║██║░░██╗██╔═██╗░  ░░░██║░░░██║░░██║
██████╦╝██║░░██║╚█████╔╝██║░╚██╗  ░░░██║░░░╚█████╔╝
╚═════╝░╚═╝░░╚═╝░╚════╝░╚═╝░░╚═╝  ░░░╚═╝░░░░╚════╝░

██████╗░██╗░░░██╗███████╗░█████╗░██████╗░██╗
██╔══██╗╚██╗░██╔╝██╔════╝██╔══██╗██╔══██╗██║
██████╔╝░╚████╔╝░█████╗░░███████║██████╔╝██║
██╔═══╝░░░╚██╔╝░░██╔══╝░░██╔══██║██╔══██╗╚═╝
██║░░░░░░░░██║░░░██║░░░░░██║░░██║██║░░██║██╗
╚═╝░░░░░░░░╚═╝░░░╚═╝░░░░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝
            """)
            time.sleep(3)
            ndt=datetime.datetime.now
            print(ndt)

        else:
            print("Password incorrect")
            time.sleep(1000)
        time.sleep(8)
        dvename = str(input("Please enter a device name:"))
        delay_print(dvename)
        time.sleep(1)
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print("                                                                                                    ")
        time.sleep(0.7)
        print("                                                                                       ")
        print("                                                                                                    ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        time.sleep(1)    
        print(
            "                                                                                                           ")
        print(
            Fore.LIGHTCYAN_EX+Style.DIM+"                            ....  .     ....   ...  ......                                 Notification                         ")
        print("                                                                                       Your installation is",
            Fore.LIGHTCYAN_EX+Style.DIM+"                            .... .  .   ....   .... ......                                 221023.2236                       ")
        print(
            Fore.LIGHTCYAN_EX+Style.DIM+"                            .... .  .   ....   .... ......                                 Notification                   ")
        print(
            Fore.LIGHTCYAN_EX+Style.DIM+"                            .... .  .   ....   .... ......                             Welcome to PyFar!                 ")
        print(
            Fore.LIGHTCYAN_EX+Style.DIM+"                            .... .  .   ....   .... ......                                                    ")
        time.sleep(2)
        def options():
            delay_print("Options:")
            delay_print("""
            [1] Calculator
            [2] Settings
            [3] Shutdown
            [4] Restart
            [5] Sleep
            [6] Hibernate
            [7] FileBank
            [8] PyDrive
            [9] PyStore
            """)
        options
        selc=int(input("[?] "))
        if selc == 1:
            print(Fore.GREEN+"Launching Calculator app.")
            time.sleep(0.5)
            print(Fore.GREEN+"Launching Calculator app..")
            time.sleep(0.5)
            print(Fore.GREEN+"Launching Calculator app...")
            time.sleep(1)
            for i in range(20):
                print("       ")
                time.sleep(0.1)
            print("   Calculator")
            print("       ")
            fnum = int(input("Please enter a number: "))
            time.sleep(0.2)
            numc = str(input("Please enter +, -, * or /"))
            time.sleep(0.2)
            snum = int(input("Please enter another number: "))
            time.sleep(1)
            delay_print("Please wait...")
            def htc(quit):
                fnum = int(input("Please enter a number: "))
                time.sleep(0.2)
                numc = str(input("Please enter +, -, * or /"))
                time.sleep(0.2)
                snum = int(input("Please enter another number: "))
                time.sleep(1)
                delay_print("Please wait...")
                time.sleep(3)
                if numc == "+":
                    rcnum = fnum+snum
                elif numc == "-":
                    rcnum = fnum-snum
                elif numc == "*":
                    rcnum = fnum*snum
                elif numc == "/":
                    rcnum = fnum/snum
                elif numc == "Quit":
                    return quit
                else:
                    print(Fore.RED+"ERROR 404")
                    rcnum = "Only enter +, -, * or / Contact support at the 阿塊 Discord server if you believe that's a bug."
                    delay_print(rcnum)
            
        time.sleep(2)
        print("Report problems at the 阿塊 Discord server.")
        time.sleep(2)
        print("Not sponsored by Republic of Gamers.")
        time.sleep(2)
        print(Style.BRIGHT+"Thank you for choosing PyOSes!")
        time.sleep(0.5)
        print(Style.DIM+Fore.BLUE+"Credits:")
        time.sleep(0.5)
        print(Style.DIM+"(nicknames)")
        time.sleep(0.5)
        print(Fore.GREEN+"Woody")
        time.sleep(0.5)
        print(Fore.RED+"Special thanks to:")
        time.sleep(0.5)
        print(Back.LIGHTMAGENTA_EX+"My coding teacher for making a Ice Cream idea to change.")
        time.sleep(0.5)
        print(Style.BRIGHT+"???%")
        time.sleep(0.5)
        print(Style.BRIGHT+"Helped me fix errors.")
        time.sleep(1)
        print(Style.DIM+"And everyone I forgot")
        time.sleep(0.5)
        print(Style.DIM+"Thank you guys all for helping me make this incredible OS!")
        time.sleep(0.5)
        print(Fore.LIGHTCYAN_EX+"Did you read all of this?")
        time.sleep(5)
        webbrowser.open("https://woodylai20130714.wixsite.com/my-site/who-we-are")
        time.sleep(15)
        break
    elif identity == "usernotfound":
        print(Fore.RED+"PyFar Error:User@login 404")
        time.sleep(0.5)
        print(Fore.RED+"UserNotFound/Expected or bad value")
        time.sleep(1)
        print(Fore.RED+"User:",username,"not found/Expected or value is incorrect.")
        print(Fore.BLUE+"Report problem at the 阿塊 Discord server.")
        time.sleep(5)
        break
    else:
        print(Fore.RED+"PyFar Error:Expected or bad value")
        print(Fore.BLUE+"Report problem at the 阿塊 Discord server.")
        time.sleep(5)
        break